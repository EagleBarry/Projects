function printNumbersInReversedOrder(arr){
    let reversed = arr.reverse();
    console.log(reversed.join('\n'));
}

printNumbersInReversedOrder([
    '10',
    '15',
    '20'
])