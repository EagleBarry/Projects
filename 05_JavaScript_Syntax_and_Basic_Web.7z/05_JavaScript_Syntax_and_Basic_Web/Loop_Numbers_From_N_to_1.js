function loopNumbersFromNto1(n){
    for(let i = Number(n); i >= 1; i--){
        console.log(i);
    }
}

loopNumbersFromNto1('5')