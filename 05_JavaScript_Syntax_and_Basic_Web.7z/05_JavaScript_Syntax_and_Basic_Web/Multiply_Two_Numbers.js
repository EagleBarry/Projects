function multiplyTwoNumbers(arr){
    let a = Number(arr[0]);
    let b = Number(arr[1]);
    console.log(a * b)
}

multiplyTwoNumbers([
    '2',
    '3'
])