function sumTwoNumbers(nums){
    let a = Number(nums[0]);
    let b = Number(nums[1]);
    console.log(a + b);
}

sumTwoNumbers(['10', '20']);