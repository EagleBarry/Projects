function printNumbersFrom1ToN(n){
    for (let i = 1; i <= n; i++){
        console.log(i);
    }
}

printNumbersFrom1ToN('5')