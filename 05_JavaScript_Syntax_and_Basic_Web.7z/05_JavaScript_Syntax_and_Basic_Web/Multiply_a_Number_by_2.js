function multiplyANumberBy2(arr){
    let input = Number(arr[0]);
    console.log(input * 2)
}

multiplyANumberBy2(['2'])